/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.ArrayList;
import java.io.*;   

/**
 * This class manages all data shared across GUI windows
 * @author Evan Darmanto
 * Date: 12/03/25
 * Assignment: Stage 4 Final Project, CSCI 2210
 */
public class DataManager {
    private static DataManager instance;
    
    private ArrayList<Customer> customers;
    private ArrayList<DeliveryDriver> drivers;
    private ArrayList<Order> orders;
    private ArrayList<Payment> payments;
    private ArrayList<Restaurant> restaurants;
    private ArrayList<SupportStaff> supportStaff;
    private PersonManager personManager;
    
    // File paths for data persistence
    private static final String DATA_FOLDER = "data/";
    private static final String CUSTOMERS_FILE = DATA_FOLDER + "customers.txt";
    private static final String DRIVERS_FILE = DATA_FOLDER + "drivers.txt";
    private static final String ORDERS_FILE = DATA_FOLDER + "orders.txt";
    private static final String PAYMENTS_FILE = DATA_FOLDER + "payments.txt";
    private static final String RESTAURANTS_FILE = DATA_FOLDER + "restaurants.txt";
    private static final String STAFF_FILE = DATA_FOLDER + "staff.txt";
    
    /**
     * Private constructor for singleton pattern
     */
    private DataManager() {
        customers = new ArrayList<>();
        drivers = new ArrayList<>();
        orders = new ArrayList<>();
        payments = new ArrayList<>();
        restaurants = new ArrayList<>();
        supportStaff = new ArrayList<>();
        personManager = new PersonManager();
        
        // Create data folder if it doesn't exist
        createDataFolder();
        
        // Try to load data from files
        if (!loadAllData()) {
            // If no saved data exists, initialize with dummy data
            initializeDummyData();
            saveAllData(); // Save the dummy data
        }
    }
    
    /**
     * Get singleton instance
     */
    public static DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }
    
    /**
     * Initialize with dummy data for testing
     */
    private void initializeDummyData() {
        // Add 3 customers
        Customer c1 = new Customer("John Doe", 30);
        c1.setEmail("john@email.com");
        c1.setAddress("123 Main St");
        c1.getAllergies().add("Peanuts");
        customers.add(c1);
        personManager.addCustomer(c1);
        
        Customer c2 = new Customer("Jane Smith", 25);
        c2.setEmail("jane@email.com");
        c2.setAddress("456 Oak Ave");
        customers.add(c2);
        personManager.addCustomer(c2);
        
        Customer c3 = new Customer("Bob Johnson", 35);
        c3.setEmail("bob@email.com");
        c3.setAddress("789 Pine Rd");
        c3.getAllergies().add("Dairy");
        customers.add(c3);
        personManager.addCustomer(c3);
        
        // Add 3 drivers
        DeliveryDriver d1 = new DeliveryDriver("Mike Williams", 28, 1001);
        d1.setEmail("mike@delivery.com");
        drivers.add(d1);
        personManager.addDriver(d1);
        
        DeliveryDriver d2 = new DeliveryDriver("Lisa Brown", 32, 1002);
        d2.setEmail("lisa@delivery.com");
        drivers.add(d2);
        personManager.addDriver(d2);
        
        DeliveryDriver d3 = new DeliveryDriver("Tom Davis", 27, 1003);
        d3.setEmail("tom@delivery.com");
        drivers.add(d3);
        personManager.addDriver(d3);
        
        // Add 2 orders
        Order o1 = new Order(c1);
        o1.updateOrderStatus("Pending");
        o1.setTimeAndDate("12:30 PM", "12/09/2024");
        o1.setSpecialInstructions("Ring doorbell");
        orders.add(o1);
        
        Order o2 = new Order(c2);
        o2.updateOrderStatus("In Progress");
        o2.setTimeAndDate("01:15 PM", "12/09/2024");
        orders.add(o2);
        
        // Add 2 payments
        Payment p1 = new Payment(1, 1);
        p1.setSubtotal(25.99f);
        p1.setTaxAmount(2.08f);
        p1.setDeliveryFee(5.00f);
        p1.calculateTotal();
        payments.add(p1);
        
        Payment p2 = new Payment(2, 2);
        p2.setSubtotal(18.50f);
        p2.setTaxAmount(1.48f);
        p2.setDeliveryFee(5.00f);
        p2.calculateTotal();
        payments.add(p2);
        
        // Add 2 restaurants
        Restaurant r1 = new Restaurant(1, "Pizza Palace", "575-555-0100", "10:00 AM");
        MenuItem item1 = new MenuItem(1, "Pepperoni Pizza", "Classic pepperoni", 12.99f);
        item1.setCategory("Main Course");
        r1.getMenu().addMenuItem(item1);
        
        MenuItem item2 = new MenuItem(2, "Caesar Salad", "Fresh romaine", 8.99f);
        item2.setCategory("Appetizer");
        r1.getMenu().addMenuItem(item2);
        restaurants.add(r1);
        
        Restaurant r2 = new Restaurant(2, "Burger King", "575-555-0200", "09:00 AM");
        MenuItem item3 = new MenuItem(3, "Cheeseburger", "With cheese", 9.99f);
        item3.setCategory("Main Course");
        r2.getMenu().addMenuItem(item3);
        
        MenuItem item4 = new MenuItem(4, "French Fries", "Crispy fries", 3.99f);
        item4.setCategory("Appetizer");
        r2.getMenu().addMenuItem(item4);
        restaurants.add(r2);
        
        // Add 2 support staff
        SupportStaff s1 = new SupportStaff("Emma Davis", 26, 2001, 0, "Order Issues");
        s1.setEmail("emma@support.com");
        supportStaff.add(s1);
        personManager.addStaff(s1);
        
        SupportStaff s2 = new SupportStaff("Alex Martinez", 29, 2002, 0, "Payment Issues");
        s2.setEmail("alex@support.com");
        supportStaff.add(s2);
        personManager.addStaff(s2);
    }
    
    // Getters
    public ArrayList<Customer> getCustomers() {
        return customers;
    }
    
    public ArrayList<DeliveryDriver> getDrivers() {
        return drivers;
    }
    
    public ArrayList<Order> getOrders() {
        return orders;
    }
    
    public ArrayList<Payment> getPayments() {
        return payments;
    }
    
    public ArrayList<Restaurant> getRestaurants() {
        return restaurants;
    }
    
    public ArrayList<SupportStaff> getSupportStaff() {
        return supportStaff;
    }
    
    public PersonManager getPersonManager() {
        return personManager;
    }
    
    // ============================================================
    // FILE PERSISTENCE METHODS
    // ============================================================
    
    /**
     * Create data folder if it doesn't exist
     */
    private void createDataFolder() {
        File folder = new File(DATA_FOLDER);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }
    
    /**
     * Save all data to files
     */
    public void saveAllData() {
        saveCustomers();
        saveDrivers();
        saveOrders();
        savePayments();
        saveRestaurants();
        saveStaff();
        System.out.println("✓ All data saved successfully!");
    }
    
    /**
     * Load all data from files
     * @return true if data was loaded, false if files don't exist
     */
    private boolean loadAllData() {
        File customersFile = new File(CUSTOMERS_FILE);
        if (!customersFile.exists()) {
            return false; // No saved data
        }
        
        loadCustomers();
        loadDrivers();
        loadOrders();
        loadPayments();
        loadRestaurants();
        loadStaff();
        
        System.out.println("✓ All data loaded successfully!");
        return true;
    }
    
    /**
     * Save customers to file
     */
    private void saveCustomers() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(CUSTOMERS_FILE))) {
            for (Customer c : customers) {
                String email = (c.getEmail() != null) ? c.getEmail() : "";
                String address = (c.getAddress() != null) ? c.getAddress() : "";
                String allergies = String.join(",", c.getAllergies());
                
                writer.println(c.getName() + "|" + c.getAge() + "|" + email + "|" + 
                             address + "|" + allergies);
            }
        } catch (Exception e) {
            System.err.println("Error saving customers: " + e.getMessage());
        }
    }
    
    /**
     * Load customers from file
     */
    private void loadCustomers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CUSTOMERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 2) {
                    Customer c = new Customer(parts[0], Integer.parseInt(parts[1]));
                    if (parts.length > 2 && !parts[2].isEmpty()) {
                        c.setEmail(parts[2]);
                    }
                    if (parts.length > 3 && !parts[3].isEmpty()) {
                        c.setAddress(parts[3]);
                    }
                    if (parts.length > 4 && !parts[4].isEmpty()) {
                        for (String allergy : parts[4].split(",")) {
                            c.getAllergies().add(allergy.trim());
                        }
                    }
                    customers.add(c);
                    personManager.addCustomer(c);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading customers: " + e.getMessage());
        }
    }
    
    /**
     * Save drivers to file
     */
    private void saveDrivers() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(DRIVERS_FILE))) {
            for (DeliveryDriver d : drivers) {
                String email = (d.getEmail() != null) ? d.getEmail() : "";
                writer.println(d.getName() + "|" + d.getAge() + "|" + d.getId() + "|" + email);
            }
        } catch (Exception e) {
            System.err.println("Error saving drivers: " + e.getMessage());
        }
    }
    
    /**
     * Load drivers from file
     */
    private void loadDrivers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(DRIVERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 3) {
                    DeliveryDriver d = new DeliveryDriver(parts[0], Integer.parseInt(parts[1]), 
                                                         Integer.parseInt(parts[2]));
                    if (parts.length > 3 && !parts[3].isEmpty()) {
                        d.setEmail(parts[3]);
                    }
                    drivers.add(d);
                    personManager.addDriver(d);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading drivers: " + e.getMessage());
        }
    }
    
    /**
     * Save orders to file
     */
    private void saveOrders() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ORDERS_FILE))) {
            for (Order o : orders) {
                String status = (o.getOrderStatus() != null) ? o.getOrderStatus() : "Pending";
                String timeDate = (o.getTimeAndDate() != null) ? o.getTimeAndDate() : "";
                String address = (o.getDeliveryAddress() != null) ? o.getDeliveryAddress() : "";
                String instructions = (o.getSpecialInstructions() != null) ? o.getSpecialInstructions() : "";
                
                writer.println(status + "|" + timeDate + "|" + address + "|" + instructions);
            }
        } catch (Exception e) {
            System.err.println("Error saving orders: " + e.getMessage());
        }
    }
    
    /**
     * Load orders from file
     */
    private void loadOrders() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERS_FILE))) {
            String line;
            int orderNum = 1;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 3) {
                    // Create a dummy customer for the order
                    Customer dummyCustomer = new Customer("Order Customer " + orderNum, 25);
                    dummyCustomer.setAddress(parts[2]); // Set the delivery address
                    
                    Order o = new Order(dummyCustomer);
                    o.updateOrderStatus(parts[0]);
                    
                    // Parse time and date
                    if (!parts[1].isEmpty() && parts[1].contains(",")) {
                        String[] timeDateParts = parts[1].split(",");
                        if (timeDateParts.length == 2) {
                            o.setTimeAndDate(timeDateParts[0].trim(), timeDateParts[1].trim());
                        }
                    }
                    
                    if (parts.length > 3 && !parts[3].isEmpty()) {
                        o.setSpecialInstructions(parts[3]);
                    }
                    orders.add(o);
                    orderNum++;
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading orders: " + e.getMessage());
        }
    }
    
    /**
     * Save payments to file
     */
    private void savePayments() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(PAYMENTS_FILE))) {
            for (int i = 0; i < payments.size(); i++) {
                Payment p = payments.get(i);
                // Save payment ID (index+1) and order ID (index+1) for simplicity
                writer.println((i + 1) + "|" + (i + 1) + "|0.00|0.00|0.00");
            }
        } catch (Exception e) {
            System.err.println("Error saving payments: " + e.getMessage());
        }
    }
    
    /**
     * Load payments from file
     */
    private void loadPayments() {
        try (BufferedReader reader = new BufferedReader(new FileReader(PAYMENTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 2) {
                    Payment p = new Payment(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
                    payments.add(p);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading payments: " + e.getMessage());
        }
    }
    
    /**
     * Save restaurants to file
     */
    private void saveRestaurants() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(RESTAURANTS_FILE))) {
            for (int i = 0; i < restaurants.size(); i++) {
                Restaurant r = restaurants.get(i);
                writer.println(r.getRestaurantID() + "|" + r.getName() + "|" + 
                             r.provideRestaurantInfo().replaceAll("\n", "\\\\n"));
            }
        } catch (Exception e) {
            System.err.println("Error saving restaurants: " + e.getMessage());
        }
    }
    
    /**
     * Load restaurants from file
     */
    private void loadRestaurants() {
        try (BufferedReader reader = new BufferedReader(new FileReader(RESTAURANTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 2) {
                    Restaurant r = new Restaurant(Integer.parseInt(parts[0]), parts[1], 
                                                 "555-0000", "9:00 AM");
                    restaurants.add(r);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading restaurants: " + e.getMessage());
        }
    }
    
    /**
     * Save support staff to file
     */
    private void saveStaff() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(STAFF_FILE))) {
            for (SupportStaff s : supportStaff) {
                String email = (s.getEmail() != null) ? s.getEmail() : "";
                writer.println(s.getName() + "|" + s.getAge() + "|" + s.getSupportStaffID() + "|" + 
                             email + "|" + (s.isAvailable() ? "1" : "0"));
            }
        } catch (Exception e) {
            System.err.println("Error saving staff: " + e.getMessage());
        }
    }
    
    /**
     * Load support staff from file
     */
    private void loadStaff() {
        try (BufferedReader reader = new BufferedReader(new FileReader(STAFF_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 3) {
                    SupportStaff s = new SupportStaff(parts[0], Integer.parseInt(parts[1]), 
                                                     Integer.parseInt(parts[2]), 0, "General Support");
                    if (parts.length > 3 && !parts[3].isEmpty()) {
                        s.setEmail(parts[3]);
                    }
                    supportStaff.add(s);
                    personManager.addStaff(s);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading staff: " + e.getMessage());
        }
    }
}