
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 * This class creates the GUI for the staff management window.
 * @author Lauren White
 * Date: 12/1/25
 * Assignment: Stage 4 Final Project, CSCI 2210 
 */
public class StaffManagementGUI extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(StaffManagementGUI.class.getName());
    private DataManager dataManager;

    /**
     * Creates new form StaffManagementGUI
     */
    public StaffManagementGUI() {
        dataManager = DataManager.getInstance();
        initComponents();
        loadStaff();
        
        // Reload staff when switching tabs
        if (tabStaffManagement != null) {
            tabStaffManagement.addChangeListener(e -> loadStaff());
        }
    }
    
    /**
    * Load staff into combo boxes and list
    */
    private void loadStaff() {
        cmbAssignStaffList.removeAllItems();
        cmbSelectStaffForResolveIssue.removeAllItems();
        cmbSelectStaffForCustomerInfo.removeAllItems();
        cmbStaffMembers.removeAllItems();
        DefaultListModel<String> listModel = new DefaultListModel<>();

        for (int i = 0; i < dataManager.getSupportStaff().size(); i++) {
            SupportStaff staff = dataManager.getSupportStaff().get(i);
            String display = (i + 1) + ". " + staff.getName() + " - ID: " + staff.getSupportStaffID();
            cmbAssignStaffList.addItem(display);
            cmbSelectStaffForResolveIssue.addItem(display);
            cmbSelectStaffForCustomerInfo.addItem(display);
            cmbStaffMembers.addItem(display);

            String listDisplay = staff.getName() + ", ID: " + staff.getSupportStaffID() + 
                               ", Available: " + (staff.isAvailable() ? "Yes" : "No") +
                               ", Issue Type: " + staff.getIssueType();
            listModel.addElement(listDisplay);
        }

        lstAllSupportStaff.setModel(listModel);
    }

    /**
     * Clear add staff form
     */
    private void clearAddStaffForm() {
        txtName.setText("");
        txtAge.setText("");
        txtStaffID.setText("");
        txtEmail.setText("");
        txtIssueType.setText("");
    }

    /**
     * Load customer and order information
     */
    private String loadCustomerInfo(SupportStaff staff) {
        StringBuilder info = new StringBuilder();
        info.append("═══════════════════════════════════════\n");
        info.append("STAFF MEMBER: ").append(staff.getName()).append("\n");
        info.append("Staff ID: ").append(staff.getSupportStaffID()).append("\n");
        info.append("Status: ").append(staff.isAvailable() ? "Available" : "Busy").append("\n");
        info.append("Current Issue Type: ").append(staff.getIssueType()).append("\n");
        info.append("═══════════════════════════════════════\n\n");

        info.append("CUSTOMERS IN SYSTEM:\n");
        info.append("───────────────────────────────────────\n");

        if (dataManager.getCustomers().isEmpty()) {
            info.append("No customers in the system.\n");
        } else {
            for (int i = 0; i < dataManager.getCustomers().size(); i++) {
                Customer c = dataManager.getCustomers().get(i);
                info.append("\nCustomer ").append(i + 1).append(":\n");
                info.append("  Name: ").append(c.getName()).append("\n");
                info.append("  Email: ").append(c.getEmail()).append("\n");
                info.append("  Address: ").append(c.getAddress()).append("\n");
                info.append("  Age: ").append(c.getAge()).append("\n");
            }
        }

        info.append("\n═══════════════════════════════════════\n");
        info.append("RECENT ORDERS:\n");
        info.append("───────────────────────────────────────\n");

        if (dataManager.getOrders().isEmpty()) {
            info.append("No orders in the system.\n");
        } else {
            for (int i = 0; i < dataManager.getOrders().size(); i++) {
                Order order = dataManager.getOrders().get(i);
                info.append("\nOrder ").append(i + 1).append(":\n");
                info.append("  Status: ").append(order.getOrderStatus()).append("\n");
                info.append("  Time: ").append(order.getTimeAndDate()).append("\n");
            }
        }  
        return info.toString();
    }
    
    /**
     * Helper method to set staff availability
     */
    private void setStaffAvailability(SupportStaff staff, boolean available) {
        try {
            java.lang.reflect.Field availableField = SupportStaff.class.getDeclaredField("available");
            availableField.setAccessible(true);
            availableField.setBoolean(staff, available);
        } catch (Exception e) {
            System.err.println("Error setting availability: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGrpNewStatus = new javax.swing.ButtonGroup();
        tabStaffManagement = new javax.swing.JTabbedPane();
        pnlAddNewSupportStaff = new javax.swing.JPanel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblAge = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        lblStaffID = new javax.swing.JLabel();
        txtStaffID = new javax.swing.JTextField();
        btnAddStaff = new javax.swing.JButton();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblInitialIssueType = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        pnlDeleteStaff = new javax.swing.JPanel();
        lblDeleteStaff = new javax.swing.JLabel();
        cmbDeleteStaff = new javax.swing.JComboBox<>();
        btnDeleteStaff = new javax.swing.JButton();
        pnlViewAllSupportStaff = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstAllSupportStaff = new javax.swing.JList<>();
        pnlAssignIssue = new javax.swing.JPanel();
        cmbAssignStaffList = new javax.swing.JComboBox<>();
        lblSelectStaffForIssue = new javax.swing.JLabel();
        lblOrderID = new javax.swing.JLabel();
        txtOrderID = new javax.swing.JTextField();
        btnAssignIssue = new javax.swing.JButton();
        txtIssueType = new javax.swing.JTextField();
        lblIssueType = new javax.swing.JLabel();
        pnlUpdateIssueStatus = new javax.swing.JPanel();
        cmbStaffMembers = new javax.swing.JComboBox<>();
        lblSelectStaffMemberForStatus = new javax.swing.JLabel();
        lblCurrentStatus = new javax.swing.JLabel();
        txtCurrentStatus = new javax.swing.JTextField();
        lblSelectNewStatus = new javax.swing.JLabel();
        btnGetStatus = new javax.swing.JButton();
        btnUpdateStatus = new javax.swing.JButton();
        rdoOpen = new javax.swing.JRadioButton();
        rdoInProgress = new javax.swing.JRadioButton();
        rdoResolved = new javax.swing.JRadioButton();
        rdoClosed = new javax.swing.JRadioButton();
        pnlResolveIssue = new javax.swing.JPanel();
        lblSelectStaffForResolveIssue = new javax.swing.JLabel();
        cmbSelectStaffForResolveIssue = new javax.swing.JComboBox<>();
        btnResolveIssue = new javax.swing.JButton();
        pnlViewStaffCustomerInfo = new javax.swing.JPanel();
        lblSelectStaffForCustomerInfo = new javax.swing.JLabel();
        cmbSelectStaffForCustomerInfo = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtOrderInfo = new javax.swing.JTextArea();
        lblOrderInfo = new javax.swing.JLabel();
        btnViewCustomerInfo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Support Staff Management");

        tabStaffManagement.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        tabStaffManagement.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        pnlAddNewSupportStaff.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Add New Support Staff", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        lblName.setText("First and Last Name");

        lblAge.setText("Age");

        lblStaffID.setText("Staff ID");

        btnAddStaff.setText("Add New Staff Member");
        btnAddStaff.addActionListener(this::btnAddStaffActionPerformed);

        lblEmail.setText("Email");

        lblInitialIssueType.setText("Initial Issue Type (or 'None')");

        javax.swing.GroupLayout pnlAddNewSupportStaffLayout = new javax.swing.GroupLayout(pnlAddNewSupportStaff);
        pnlAddNewSupportStaff.setLayout(pnlAddNewSupportStaffLayout);
        pnlAddNewSupportStaffLayout.setHorizontalGroup(
            pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAddNewSupportStaffLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAddStaff)
                .addContainerGap())
            .addGroup(pnlAddNewSupportStaffLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtStaffID, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblStaffID, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlAddNewSupportStaffLayout.createSequentialGroup()
                        .addGroup(pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblAge, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(txtEmail)
                    .addComponent(jTextField1)
                    .addComponent(lblInitialIssueType, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(157, Short.MAX_VALUE))
        );
        pnlAddNewSupportStaffLayout.setVerticalGroup(
            pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAddNewSupportStaffLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lblStaffID)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtStaffID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAge)
                    .addComponent(lblName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlAddNewSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblEmail)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblInitialIssueType)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(btnAddStaff)
                .addContainerGap())
        );

        tabStaffManagement.addTab("Add New Support Staff", pnlAddNewSupportStaff);

        pnlDeleteStaff.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Delete Support Staff", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        lblDeleteStaff.setText("Select a Staff Member");

        cmbDeleteStaff.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnDeleteStaff.setText("Delete Staff Member");

        javax.swing.GroupLayout pnlDeleteStaffLayout = new javax.swing.GroupLayout(pnlDeleteStaff);
        pnlDeleteStaff.setLayout(pnlDeleteStaffLayout);
        pnlDeleteStaffLayout.setHorizontalGroup(
            pnlDeleteStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDeleteStaffLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDeleteStaff)
                .addContainerGap())
            .addGroup(pnlDeleteStaffLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(pnlDeleteStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbDeleteStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDeleteStaff))
                .addContainerGap(184, Short.MAX_VALUE))
        );
        pnlDeleteStaffLayout.setVerticalGroup(
            pnlDeleteStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDeleteStaffLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(lblDeleteStaff)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbDeleteStaff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 244, Short.MAX_VALUE)
                .addComponent(btnDeleteStaff)
                .addContainerGap())
        );

        tabStaffManagement.addTab("Delete Support Staff", pnlDeleteStaff);

        pnlViewAllSupportStaff.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "View All Support Staff", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        lstAllSupportStaff.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "ID, Name, Email", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lstAllSupportStaff);

        javax.swing.GroupLayout pnlViewAllSupportStaffLayout = new javax.swing.GroupLayout(pnlViewAllSupportStaff);
        pnlViewAllSupportStaff.setLayout(pnlViewAllSupportStaffLayout);
        pnlViewAllSupportStaffLayout.setHorizontalGroup(
            pnlViewAllSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlViewAllSupportStaffLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlViewAllSupportStaffLayout.setVerticalGroup(
            pnlViewAllSupportStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlViewAllSupportStaffLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 319, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabStaffManagement.addTab("View All Support Staff", pnlViewAllSupportStaff);

        pnlAssignIssue.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Assign Issue to Staff", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        cmbAssignStaffList.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblSelectStaffForIssue.setText("Select a Staff Member");

        lblOrderID.setText("Enter Order ID");

        btnAssignIssue.setText("Assign Issue");
        btnAssignIssue.addActionListener(this::btnAssignIssueActionPerformed);

        lblIssueType.setText("Enter Issue Type");

        javax.swing.GroupLayout pnlAssignIssueLayout = new javax.swing.GroupLayout(pnlAssignIssue);
        pnlAssignIssue.setLayout(pnlAssignIssueLayout);
        pnlAssignIssueLayout.setHorizontalGroup(
            pnlAssignIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAssignIssueLayout.createSequentialGroup()
                .addGap(0, 267, Short.MAX_VALUE)
                .addComponent(btnAssignIssue))
            .addGroup(pnlAssignIssueLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnlAssignIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cmbAssignStaffList, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSelectStaffForIssue, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlAssignIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblIssueType, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                    .addComponent(txtIssueType))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlAssignIssueLayout.setVerticalGroup(
            pnlAssignIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAssignIssueLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(pnlAssignIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelectStaffForIssue)
                    .addComponent(lblIssueType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlAssignIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbAssignStaffList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIssueType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblOrderID)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 178, Short.MAX_VALUE)
                .addComponent(btnAssignIssue)
                .addContainerGap())
        );

        tabStaffManagement.addTab("Assign Issue to Staff", pnlAssignIssue);

        pnlUpdateIssueStatus.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Update Issue Status", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        cmbStaffMembers.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblSelectStaffMemberForStatus.setText("Select a Staff Member");

        lblCurrentStatus.setText("Current Status");

        txtCurrentStatus.setEditable(false);
        txtCurrentStatus.setCaretColor(new java.awt.Color(255, 255, 255));

        lblSelectNewStatus.setText("Select New Issue Status");

        btnGetStatus.setText("Get Staff Member's Status");
        btnGetStatus.addActionListener(this::btnGetStatusActionPerformed);

        btnUpdateStatus.setText("Update Issue Status");
        btnUpdateStatus.addActionListener(this::btnUpdateStatusActionPerformed);

        btnGrpNewStatus.add(rdoOpen);
        rdoOpen.setText("Open");

        btnGrpNewStatus.add(rdoInProgress);
        rdoInProgress.setText("In Progress");

        btnGrpNewStatus.add(rdoResolved);
        rdoResolved.setText("Resolved");

        btnGrpNewStatus.add(rdoClosed);
        rdoClosed.setText("Closed");

        javax.swing.GroupLayout pnlUpdateIssueStatusLayout = new javax.swing.GroupLayout(pnlUpdateIssueStatus);
        pnlUpdateIssueStatus.setLayout(pnlUpdateIssueStatusLayout);
        pnlUpdateIssueStatusLayout.setHorizontalGroup(
            pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateIssueStatusLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateIssueStatusLayout.createSequentialGroup()
                        .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdoClosed, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdoResolved, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdoInProgress, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlUpdateIssueStatusLayout.createSequentialGroup()
                        .addComponent(lblSelectNewStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlUpdateIssueStatusLayout.createSequentialGroup()
                        .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlUpdateIssueStatusLayout.createSequentialGroup()
                                .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbStaffMembers, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblSelectStaffMemberForStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblCurrentStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCurrentStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(rdoOpen, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUpdateIssueStatusLayout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(btnGetStatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUpdateStatus)
                .addGap(12, 12, 12))
        );
        pnlUpdateIssueStatusLayout.setVerticalGroup(
            pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateIssueStatusLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelectStaffMemberForStatus)
                    .addComponent(lblCurrentStatus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbStaffMembers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCurrentStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSelectNewStatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rdoOpen)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rdoInProgress)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rdoResolved)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rdoClosed)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addGroup(pnlUpdateIssueStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGetStatus)
                    .addComponent(btnUpdateStatus))
                .addContainerGap())
        );

        tabStaffManagement.addTab("Update Issue Status", pnlUpdateIssueStatus);

        pnlResolveIssue.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Resolve Issue", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        lblSelectStaffForResolveIssue.setText("Select a Staff Member");

        cmbSelectStaffForResolveIssue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnResolveIssue.setText("Resolve Issue");
        btnResolveIssue.addActionListener(this::btnResolveIssueActionPerformed);

        javax.swing.GroupLayout pnlResolveIssueLayout = new javax.swing.GroupLayout(pnlResolveIssue);
        pnlResolveIssue.setLayout(pnlResolveIssueLayout);
        pnlResolveIssueLayout.setHorizontalGroup(
            pnlResolveIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlResolveIssueLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(pnlResolveIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblSelectStaffForResolveIssue, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
                    .addComponent(cmbSelectStaffForResolveIssue, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(206, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlResolveIssueLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnResolveIssue)
                .addContainerGap())
        );
        pnlResolveIssueLayout.setVerticalGroup(
            pnlResolveIssueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlResolveIssueLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblSelectStaffForResolveIssue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbSelectStaffForResolveIssue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 246, Short.MAX_VALUE)
                .addComponent(btnResolveIssue)
                .addContainerGap())
        );

        tabStaffManagement.addTab("Resolve Issue", pnlResolveIssue);

        pnlViewStaffCustomerInfo.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "View Staff Customer Info", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        lblSelectStaffForCustomerInfo.setText("Select a Staff Member");

        cmbSelectStaffForCustomerInfo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtOrderInfo.setEditable(false);
        txtOrderInfo.setColumns(20);
        txtOrderInfo.setRows(5);
        txtOrderInfo.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane2.setViewportView(txtOrderInfo);

        lblOrderInfo.setText("Customer/Order Information");

        btnViewCustomerInfo.setText("View Customer Info");
        btnViewCustomerInfo.addActionListener(this::btnViewCustomerInfoActionPerformed);

        javax.swing.GroupLayout pnlViewStaffCustomerInfoLayout = new javax.swing.GroupLayout(pnlViewStaffCustomerInfo);
        pnlViewStaffCustomerInfo.setLayout(pnlViewStaffCustomerInfoLayout);
        pnlViewStaffCustomerInfoLayout.setHorizontalGroup(
            pnlViewStaffCustomerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlViewStaffCustomerInfoLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(pnlViewStaffCustomerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblOrderInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlViewStaffCustomerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(cmbSelectStaffForCustomerInfo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblSelectStaffForCustomerInfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlViewStaffCustomerInfoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnViewCustomerInfo)
                .addContainerGap())
        );
        pnlViewStaffCustomerInfoLayout.setVerticalGroup(
            pnlViewStaffCustomerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlViewStaffCustomerInfoLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblSelectStaffForCustomerInfo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbSelectStaffForCustomerInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblOrderInfo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnViewCustomerInfo)
                .addContainerGap())
        );

        tabStaffManagement.addTab("View Staff Customer Info", pnlViewStaffCustomerInfo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(tabStaffManagement)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(tabStaffManagement)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddStaffActionPerformed
        try {
            // Get form data
            String name = txtName.getText().trim();
            String ageText = txtAge.getText().trim();
            String idText = txtStaffID.getText().trim();
            String email = txtEmail.getText().trim();
            String issueType = txtIssueType.getText().trim();

            // Validation
            if (name.isEmpty() || ageText.isEmpty() || idText.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please fill in all required fields:\n" +
                    "- Name\n- Age\n- Staff ID\n- Email",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Parse numbers
            int age = Integer.parseInt(ageText);
            int staffID = Integer.parseInt(idText);

            // Check if ID already exists
            for (SupportStaff s : dataManager.getSupportStaff()) {
                if (s.getSupportStaffID() == staffID) {
                    JOptionPane.showMessageDialog(this, 
                        "Staff ID " + staffID + " already exists!",
                        "Duplicate ID", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            // Set default issue type if empty
            if (issueType.isEmpty()) {
                issueType = "General Support";
            }

            // Create new staff member
            SupportStaff newStaff = new SupportStaff(name, age, staffID, 0, issueType);
            newStaff.setEmail(email);

            // Add to data manager
            dataManager.getSupportStaff().add(newStaff);
            dataManager.getPersonManager().addStaff(newStaff);
            
            dataManager.saveAllData();

            JOptionPane.showMessageDialog(this, 
                "Staff member added successfully!\n\n" +
                "Name: " + name + "\n" +
                "ID: " + staffID + "\n" +
                "Issue Type: " + issueType,
                "Success", JOptionPane.INFORMATION_MESSAGE);

            clearAddStaffForm();
            loadStaff();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid numbers for:\n" +
                "- Age (e.g., 25)\n" +
                "- Staff ID (e.g., 2001)",
                "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnAddStaffActionPerformed

    private void btnAssignIssueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignIssueActionPerformed
        int selectedIndex = cmbAssignStaffList.getSelectedIndex();
    
        if (selectedIndex < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a staff member.",
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SupportStaff staff = dataManager.getSupportStaff().get(selectedIndex);

        if (!staff.isAvailable()) {
            JOptionPane.showMessageDialog(this,
                staff.getName() + " is currently busy.",
                "Staff Busy", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Ask for issue type
        String issueType = JOptionPane.showInputDialog(this,
            "Enter issue type:",
            "Assign Issue",
            JOptionPane.QUESTION_MESSAGE);

        if (issueType != null && !issueType.trim().isEmpty()) {
            // Use the new overloaded method (no Scanner prompts!)
            staff.assignIssue(issueType, 0);
            
            dataManager.saveAllData();

            JOptionPane.showMessageDialog(this, 
                "Issue assigned successfully!\n\n" +
                "Staff: " + staff.getName() + "\n" +
                "Issue: " + issueType,
                "Success", JOptionPane.INFORMATION_MESSAGE);

            loadStaff();
        }
    }//GEN-LAST:event_btnAssignIssueActionPerformed

    private void btnGetStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGetStatusActionPerformed
        int selectedIndex = cmbStaffMembers.getSelectedIndex();
    
        if (selectedIndex < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a staff member.",
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SupportStaff staff = dataManager.getSupportStaff().get(selectedIndex);
        String status = staff.isAvailable() ? "Available" : "Busy";

        // Display in text field
        txtCurrentStatus.setText(status);

        // Also show detailed status in dialog
        JOptionPane.showMessageDialog(this,
            "Staff: " + staff.getName() + "\n" +
            "ID: " + staff.getSupportStaffID() + "\n" +
            "Status: " + status + "\n" +
            "Issue Type: " + staff.getIssueType(),
            "Staff Status", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnGetStatusActionPerformed

    private void btnUpdateStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateStatusActionPerformed
        int selectedIndex = cmbStaffMembers.getSelectedIndex();

        if (selectedIndex < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a staff member.",
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SupportStaff staff = dataManager.getSupportStaff().get(selectedIndex);

        String[] options = {"Available", "Busy"};
        int choice = JOptionPane.showOptionDialog(this,
            "Select new status for " + staff.getName() + ":",
            "Update Status",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);

        if (choice == 0) {
            // Set to available
            staff.resolveIssue();
            dataManager.saveAllData();
            JOptionPane.showMessageDialog(this, 
                staff.getName() + " is now Available.",
                "Success", JOptionPane.INFORMATION_MESSAGE);
            loadStaff();
        } else if (choice == 1) {
            // Set to busy
            setStaffAvailability(staff, false);
            dataManager.saveAllData();
            JOptionPane.showMessageDialog(this, 
                staff.getName() + " is now Busy.",
                "Success", JOptionPane.INFORMATION_MESSAGE);
            loadStaff();
        }
    }//GEN-LAST:event_btnUpdateStatusActionPerformed

    private void btnResolveIssueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResolveIssueActionPerformed
        int selectedIndex = cmbSelectStaffForResolveIssue.getSelectedIndex();
    
        if (selectedIndex < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a staff member.",
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SupportStaff staff = dataManager.getSupportStaff().get(selectedIndex);

        if (staff.isAvailable()) {
            JOptionPane.showMessageDialog(this, 
                staff.getName() + " is not busy.",
                "No Issues", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Mark issue as resolved for " + staff.getName() + "?",
            "Confirm", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            staff.resolveIssue();
            
            dataManager.saveAllData();
            
            JOptionPane.showMessageDialog(this, 
                staff.getName() + " is now available!",
                "Success", JOptionPane.INFORMATION_MESSAGE);

            loadStaff();
        }
    }//GEN-LAST:event_btnResolveIssueActionPerformed

    private void btnViewCustomerInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewCustomerInfoActionPerformed
        int selectedIndex = cmbSelectStaffForCustomerInfo.getSelectedIndex();
    
        if (selectedIndex < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a staff member.",
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SupportStaff staff = dataManager.getSupportStaff().get(selectedIndex);

        // Load customer and order information
        String info = loadCustomerInfo(staff);

        // Display in the text area
        txtOrderInfo.setText(info);

        // Also show summary in dialog
        int customerCount = dataManager.getCustomers().size();
        int orderCount = dataManager.getOrders().size();

        JOptionPane.showMessageDialog(this,
            "Customer & Order Information loaded for:\n\n" +
            "Staff: " + staff.getName() + "\n" +
            "Total Customers: " + customerCount + "\n" +
            "Total Orders: " + orderCount,
            "Information Loaded", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnViewCustomerInfoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new StaffManagementGUI().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddStaff;
    private javax.swing.JButton btnAssignIssue;
    private javax.swing.JButton btnDeleteStaff;
    private javax.swing.JButton btnGetStatus;
    private javax.swing.ButtonGroup btnGrpNewStatus;
    private javax.swing.JButton btnResolveIssue;
    private javax.swing.JButton btnUpdateStatus;
    private javax.swing.JButton btnViewCustomerInfo;
    private javax.swing.JComboBox<String> cmbAssignStaffList;
    private javax.swing.JComboBox<String> cmbDeleteStaff;
    private javax.swing.JComboBox<String> cmbSelectStaffForCustomerInfo;
    private javax.swing.JComboBox<String> cmbSelectStaffForResolveIssue;
    private javax.swing.JComboBox<String> cmbStaffMembers;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblCurrentStatus;
    private javax.swing.JLabel lblDeleteStaff;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblInitialIssueType;
    private javax.swing.JLabel lblIssueType;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblOrderID;
    private javax.swing.JLabel lblOrderInfo;
    private javax.swing.JLabel lblSelectNewStatus;
    private javax.swing.JLabel lblSelectStaffForCustomerInfo;
    private javax.swing.JLabel lblSelectStaffForIssue;
    private javax.swing.JLabel lblSelectStaffForResolveIssue;
    private javax.swing.JLabel lblSelectStaffMemberForStatus;
    private javax.swing.JLabel lblStaffID;
    private javax.swing.JList<String> lstAllSupportStaff;
    private javax.swing.JPanel pnlAddNewSupportStaff;
    private javax.swing.JPanel pnlAssignIssue;
    private javax.swing.JPanel pnlDeleteStaff;
    private javax.swing.JPanel pnlResolveIssue;
    private javax.swing.JPanel pnlUpdateIssueStatus;
    private javax.swing.JPanel pnlViewAllSupportStaff;
    private javax.swing.JPanel pnlViewStaffCustomerInfo;
    private javax.swing.JRadioButton rdoClosed;
    private javax.swing.JRadioButton rdoInProgress;
    private javax.swing.JRadioButton rdoOpen;
    private javax.swing.JRadioButton rdoResolved;
    private javax.swing.JTabbedPane tabStaffManagement;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtCurrentStatus;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtIssueType;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtOrderID;
    private javax.swing.JTextArea txtOrderInfo;
    private javax.swing.JTextField txtStaffID;
    // End of variables declaration//GEN-END:variables
}
