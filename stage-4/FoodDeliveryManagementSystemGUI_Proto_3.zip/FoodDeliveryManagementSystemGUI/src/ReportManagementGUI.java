
import java.util.ArrayList;

/**
 * This class creates the GUI for the  report management window.
 * @author Lauren White
 * Date: 12/1/25
 * Assignment: Stage 4 Final Project, CSCI 2210 
 */
public class ReportManagementGUI extends javax.swing.JFrame {
    
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ReportManagementGUI.class.getName());
    private DataManager dataManager;

    /**
     * Creates new form ReportManagementGUI
     */
    public ReportManagementGUI() {
        dataManager = DataManager.getInstance();
        initComponents();
        generateAllReports();
    }
    
    /**
    * Generate all reports and populate text areas
    */
    private void generateAllReports() {
        generateCustomerReport();
        generateDriverReport();
        generateOrderReport();
        generatePaymentReport();
        generateRestaurantReport();
        generateStaffReport();
    }

    /**
    * Generate Customer Statistics Report
    */
    private void generateCustomerReport() {
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════════╗\n");
        report.append("           CUSTOMER STATISTICS REPORT\n");
        report.append("╚════════════════════════════════════════════════╝\n\n");

        ArrayList<Customer> customers = dataManager.getCustomers();

        report.append("Total Customers: ").append(customers.size()).append("\n");
        report.append("═══════════════════════════════════════════════\n\n");

        if (customers.isEmpty()) {
            report.append("No customers in the system.\n");
        } else {
            for (int i = 0; i < customers.size(); i++) {
                Customer c = customers.get(i);
                report.append("Customer ").append(i + 1).append(":\n");
                report.append("  Name: ").append(c.getName()).append("\n");
                report.append("  Email: ").append(c.getEmail()).append("\n");
                report.append("  Address: ").append(c.getAddress()).append("\n");
                report.append("  Age: ").append(c.getAge()).append("\n");

                if (!c.getAllergies().isEmpty()) {
                    report.append("  Allergies: ");
                    for (int j = 0; j < c.getAllergies().size(); j++) {
                        report.append(c.getAllergies().get(j));
                        if (j < c.getAllergies().size() - 1) {
                            report.append(", ");
                        }
                    }
                    report.append("\n");
                }
                report.append("\n");
            }
        }

        txtCustomerStatistics.setText(report.toString());
        txtCustomerStatistics.setCaretPosition(0);
    }

    /**
     * Generate Driver Statistics Report
     */
    private void generateDriverReport() {
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════════╗\n");
        report.append("            DRIVER STATISTICS REPORT\n");
        report.append("╚════════════════════════════════════════════════╝\n\n");

        ArrayList<DeliveryDriver> drivers = dataManager.getDrivers();

        report.append("Total Drivers: ").append(drivers.size()).append("\n");
        report.append("═══════════════════════════════════════════════\n\n");

        if (drivers.isEmpty()) {
            report.append("No drivers in the system.\n");
        } else {
            for (int i = 0; i < drivers.size(); i++) {
                DeliveryDriver d = drivers.get(i);
                report.append("Driver ").append(i + 1).append(":\n");
                report.append("  Name: ").append(d.getName()).append("\n");
                report.append("  ID: ").append(d.getId()).append("\n");
                report.append("  Email: ").append(d.getEmail()).append("\n");
                report.append("  Age: ").append(d.getAge()).append("\n");

                // Try to get availability status using reflection
                try {
                    java.lang.reflect.Field availableField = DeliveryDriver.class.getDeclaredField("available");
                    availableField.setAccessible(true);
                    boolean isAvailable = availableField.getBoolean(d);
                    report.append("  Status: ").append(isAvailable ? "Available" : "Busy").append("\n");
                } catch (Exception e) {
                    // If field doesn't exist, skip status
                }

                // Get ratings if available
                try {
                    java.lang.reflect.Field ratingsField = DeliveryDriver.class.getDeclaredField("ratings");
                    ratingsField.setAccessible(true);
                    ArrayList<Integer> ratings = (ArrayList<Integer>) ratingsField.get(d);

                    if (ratings != null && !ratings.isEmpty()) {
                        double sum = 0;
                        for (int rating : ratings) {
                            sum += rating;
                        }
                        double average = sum / ratings.size();
                        report.append("  Average Rating: ").append(String.format("%.2f", average))
                              .append("/5 (").append(ratings.size()).append(" ratings)\n");
                    }
                } catch (Exception e) {
                    // Ratings not accessible
                }

                report.append("\n");
            }
        }
        txtDriverStatistics.setText(report.toString());
        txtDriverStatistics.setCaretPosition(0);
    }

   /**
    * Generate Order Statistics Report
    */
   private void generateOrderReport() {
       StringBuilder report = new StringBuilder();
       report.append("╔════════════════════════════════════════════════╗\n");
       report.append("            ORDER STATISTICS REPORT\n");
       report.append("╚════════════════════════════════════════════════╝\n\n");

       ArrayList<Order> orders = dataManager.getOrders();

       report.append("Total Orders: ").append(orders.size()).append("\n");
       report.append("═══════════════════════════════════════════════\n\n");

       if (orders.isEmpty()) {
           report.append("No orders in the system.\n");
       } else {
           // Count orders by status
           int pending = 0;
           int inProgress = 0;
           int delivered = 0;
           int cancelled = 0;

           for (Order o : orders) {
               String status = o.getOrderStatus().toLowerCase();
               if (status.contains("pending")) {
                   pending++;
               } else if (status.contains("progress") || status.contains("preparing")) {
                   inProgress++;
               } else if (status.contains("delivered") || status.contains("complete")) {
                   delivered++;
               } else if (status.contains("cancel")) {
                   cancelled++;
               }
           }

           report.append("Order Status Breakdown:\n");
           report.append("  Pending: ").append(pending).append("\n");
           report.append("  In Progress: ").append(inProgress).append("\n");
           report.append("  Delivered: ").append(delivered).append("\n");
           report.append("  Cancelled: ").append(cancelled).append("\n\n");
           report.append("───────────────────────────────────────────────\n\n");

           for (int i = 0; i < orders.size(); i++) {
               Order o = orders.get(i);
               report.append("Order ").append(i + 1).append(":\n");
               report.append("  Status: ").append(o.getOrderStatus()).append("\n");
               report.append("  Time/Date: ").append(o.getTimeAndDate()).append("\n");
               report.append("  Delivery Address: ").append(o.getDeliveryAddress()).append("\n");

               if (o.getSpecialInstructions() != null && !o.getSpecialInstructions().isEmpty()) {
                   report.append("  Special Instructions: ").append(o.getSpecialInstructions()).append("\n");
               }

               report.append("\n");
           }
       }

       txtOrderStatistics.setText(report.toString());
       txtOrderStatistics.setCaretPosition(0);
   }

    /**
     * Generate Payment Statistics Report
     */
    private void generatePaymentReport() {
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════════╗\n");
        report.append("           PAYMENT STATISTICS REPORT\n");
        report.append("╚════════════════════════════════════════════════╝\n\n");

        ArrayList<Payment> payments = dataManager.getPayments();

        report.append("Total Payments: ").append(payments.size()).append("\n");
        report.append("═══════════════════════════════════════════════\n\n");

        if (payments.isEmpty()) {
            report.append("No payments in the system.\n");
        } else {
            // Calculate total revenue
            float totalRevenue = 0;

            for (Payment p : payments) {
                totalRevenue += p.getTotal();
            }

            report.append("Financial Summary:\n");
            report.append("  Total Revenue: $").append(String.format("%.2f", totalRevenue)).append("\n");
            report.append("  Average Payment: $").append(String.format("%.2f", totalRevenue / payments.size())).append("\n\n");
            report.append("───────────────────────────────────────────────\n\n");

            for (int i = 0; i < payments.size(); i++) {
                Payment p = payments.get(i);
                report.append("Payment ").append(i + 1).append(":\n");
                report.append("  Payment ID: ").append(p.getPaymentID()).append("\n");
                report.append("  Subtotal: $").append(String.format("%.2f", p.getTotalAmount())).append("\n");
                report.append("  Tax: $").append(String.format("%.2f", p.getTaxAmount())).append("\n");
                report.append("  Delivery Fee: $").append(String.format("%.2f", p.getDeliveryFee())).append("\n");
                report.append("  Total: $").append(String.format("%.2f", p.getTotal())).append("\n");
                report.append("\n");
            }
        }

        txtPaymentStatistics.setText(report.toString());
        txtPaymentStatistics.setCaretPosition(0);
    }

    /**
     * Generate Restaurant Info Report
     */
    private void generateRestaurantReport() {
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════════╗\n");
        report.append("            RESTAURANT INFO REPORT\n");
        report.append("╚════════════════════════════════════════════════╝\n\n");

        ArrayList<Restaurant> restaurants = dataManager.getRestaurants();

        report.append("Total Restaurants: ").append(restaurants.size()).append("\n");
        report.append("═══════════════════════════════════════════════\n\n");

        if (restaurants.isEmpty()) {
            report.append("No restaurants in the system.\n");
        } else {
            int totalMenuItems = 0;

            for (Restaurant r : restaurants) {
                totalMenuItems += r.getMenu().getMenuItems().size();
            }

            report.append("Total Menu Items Across All Restaurants: ").append(totalMenuItems).append("\n");
            report.append("Average Menu Items per Restaurant: ")
                  .append(String.format("%.1f", (double) totalMenuItems / restaurants.size())).append("\n\n");
            report.append("───────────────────────────────────────────────\n\n");

            for (int i = 0; i < restaurants.size(); i++) {
                Restaurant r = restaurants.get(i);
                report.append("Restaurant ").append(i + 1).append(":\n");
                report.append("  Name: ").append(r.getName()).append("\n");
                report.append("  Phone: ").append(r.getPhoneNumber()).append("\n");
                report.append("  ").append(r.displayOperatingHours()).append("\n");
                report.append("  Delivery Fee: $").append(r.calculateDeliveryFee()).append("\n");
                report.append("  Menu Items: ").append(r.getMenu().getMenuItems().size()).append("\n");

                // Count by category
                int appetizers = r.getMenu().filterByCategory("Appetizer").size();
                int mains = r.getMenu().filterByCategory("Main Course").size();
                int desserts = r.getMenu().filterByCategory("Dessert").size();
                int beverages = r.getMenu().filterByCategory("Beverage").size();

                report.append("Appetizers: ").append(appetizers).append("\n");
                report.append("Main Courses: ").append(mains).append("\n");
                report.append("Desserts: ").append(desserts).append("\n");
                report.append("Beverages: ").append(beverages).append("\n");
                report.append("\n");
            }
        }

        txtRestaurantInfo.setText(report.toString());
        txtRestaurantInfo.setCaretPosition(0);
    }

    /**
     * Generate Support Staff Info Report
     */
    private void generateStaffReport() {
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════════╗\n");
        report.append("          SUPPORT STAFF INFO REPORT\n");
        report.append("╚════════════════════════════════════════════════╝\n\n");

        ArrayList<SupportStaff> staffList = dataManager.getSupportStaff();

        report.append("Total Support Staff: ").append(staffList.size()).append("\n");
        report.append("═══════════════════════════════════════════════\n\n");

        if (staffList.isEmpty()) {
            report.append("No support staff in the system.\n");
        } else {
            int availableStaff = 0;
            int busyStaff = 0;

            // Count availability using reflection
            for (SupportStaff s : staffList) {
                try {
                    java.lang.reflect.Field availableField = SupportStaff.class.getDeclaredField("available");
                    availableField.setAccessible(true);
                    boolean isAvailable = availableField.getBoolean(s);
                    if (isAvailable) {
                        availableStaff++;
                    } else {
                        busyStaff++;
                    }
                } catch (Exception e) {
                    // If can't access, don't count
                }
            }

            if (availableStaff > 0 || busyStaff > 0) {
                report.append("Staff Availability:\n");
                report.append("  Available: ").append(availableStaff).append("\n");
                report.append("  Busy: ").append(busyStaff).append("\n\n");
            }

            report.append("───────────────────────────────────────────────\n\n");

            for (int i = 0; i < staffList.size(); i++) {
                SupportStaff s = staffList.get(i);
                report.append("Staff Member ").append(i + 1).append(":\n");
                report.append("  Name: ").append(s.getName()).append("\n");
                report.append("  Staff ID: ").append(s.getSupportStaffID()).append("\n");
                report.append("  Email: ").append(s.getEmail()).append("\n");
                report.append("  Age: ").append(s.getAge()).append("\n");
                report.append("  Issue Type: ").append(s.getIssueType()).append("\n");

                // Try to get availability
                try {
                    java.lang.reflect.Field availableField = SupportStaff.class.getDeclaredField("available");
                    availableField.setAccessible(true);
                    boolean isAvailable = availableField.getBoolean(s);
                    report.append("  Status: ").append(isAvailable ? "Available" : "Busy").append("\n");
                } catch (Exception e) {
                    // Skip if not accessible
                }

                report.append("\n");
            }
        }
        txtSupportStaffInfo.setText(report.toString());
        txtSupportStaffInfo.setCaretPosition(0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabReports = new javax.swing.JTabbedPane();
        pnlCustomerStatistics = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtCustomerStatistics = new javax.swing.JTextArea();
        pnlDriverStatistics = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDriverStatistics = new javax.swing.JTextArea();
        pnlRestaurantInfo = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtRestaurantInfo = new javax.swing.JTextArea();
        pnlOrderStatistics = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtOrderStatistics = new javax.swing.JTextArea();
        pnlPaymentStatistics = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtPaymentStatistics = new javax.swing.JTextArea();
        pnlStaffInfo = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtSupportStaffInfo = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Manage Reports");

        tabReports.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        tabReports.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        pnlCustomerStatistics.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Customer Statistics", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        txtCustomerStatistics.setEditable(false);
        txtCustomerStatistics.setColumns(20);
        txtCustomerStatistics.setLineWrap(true);
        txtCustomerStatistics.setRows(5);
        txtCustomerStatistics.setToolTipText("");
        txtCustomerStatistics.setCaretColor(new java.awt.Color(255, 255, 255));
        txtCustomerStatistics.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        txtCustomerStatistics.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        txtCustomerStatistics.setDoubleBuffered(true);
        jScrollPane3.setViewportView(txtCustomerStatistics);

        javax.swing.GroupLayout pnlCustomerStatisticsLayout = new javax.swing.GroupLayout(pnlCustomerStatistics);
        pnlCustomerStatistics.setLayout(pnlCustomerStatisticsLayout);
        pnlCustomerStatisticsLayout.setHorizontalGroup(
            pnlCustomerStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCustomerStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlCustomerStatisticsLayout.setVerticalGroup(
            pnlCustomerStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCustomerStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabReports.addTab("Customer Statistics", pnlCustomerStatistics);

        pnlDriverStatistics.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Driver Statistics", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        txtDriverStatistics.setEditable(false);
        txtDriverStatistics.setColumns(20);
        txtDriverStatistics.setRows(5);
        txtDriverStatistics.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(txtDriverStatistics);

        javax.swing.GroupLayout pnlDriverStatisticsLayout = new javax.swing.GroupLayout(pnlDriverStatistics);
        pnlDriverStatistics.setLayout(pnlDriverStatisticsLayout);
        pnlDriverStatisticsLayout.setHorizontalGroup(
            pnlDriverStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDriverStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlDriverStatisticsLayout.setVerticalGroup(
            pnlDriverStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDriverStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabReports.addTab("Driver Statistics", pnlDriverStatistics);

        pnlRestaurantInfo.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Restaurant Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        txtRestaurantInfo.setEditable(false);
        txtRestaurantInfo.setColumns(20);
        txtRestaurantInfo.setRows(5);
        txtRestaurantInfo.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane2.setViewportView(txtRestaurantInfo);

        javax.swing.GroupLayout pnlRestaurantInfoLayout = new javax.swing.GroupLayout(pnlRestaurantInfo);
        pnlRestaurantInfo.setLayout(pnlRestaurantInfoLayout);
        pnlRestaurantInfoLayout.setHorizontalGroup(
            pnlRestaurantInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRestaurantInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlRestaurantInfoLayout.setVerticalGroup(
            pnlRestaurantInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRestaurantInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabReports.addTab("Restaurant Information", pnlRestaurantInfo);

        pnlOrderStatistics.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Order Statistics", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        txtOrderStatistics.setEditable(false);
        txtOrderStatistics.setColumns(20);
        txtOrderStatistics.setRows(5);
        txtOrderStatistics.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane4.setViewportView(txtOrderStatistics);

        javax.swing.GroupLayout pnlOrderStatisticsLayout = new javax.swing.GroupLayout(pnlOrderStatistics);
        pnlOrderStatistics.setLayout(pnlOrderStatisticsLayout);
        pnlOrderStatisticsLayout.setHorizontalGroup(
            pnlOrderStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlOrderStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlOrderStatisticsLayout.setVerticalGroup(
            pnlOrderStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlOrderStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabReports.addTab("Order Statistics", pnlOrderStatistics);

        pnlPaymentStatistics.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Payment Statistics", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        txtPaymentStatistics.setEditable(false);
        txtPaymentStatistics.setColumns(20);
        txtPaymentStatistics.setRows(5);
        txtPaymentStatistics.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane5.setViewportView(txtPaymentStatistics);

        javax.swing.GroupLayout pnlPaymentStatisticsLayout = new javax.swing.GroupLayout(pnlPaymentStatistics);
        pnlPaymentStatistics.setLayout(pnlPaymentStatisticsLayout);
        pnlPaymentStatisticsLayout.setHorizontalGroup(
            pnlPaymentStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlPaymentStatisticsLayout.setVerticalGroup(
            pnlPaymentStatisticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentStatisticsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabReports.addTab("Payment Statistics", pnlPaymentStatistics);

        pnlStaffInfo.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Support Staff Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14))); // NOI18N

        txtSupportStaffInfo.setEditable(false);
        txtSupportStaffInfo.setColumns(20);
        txtSupportStaffInfo.setRows(5);
        txtSupportStaffInfo.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane6.setViewportView(txtSupportStaffInfo);

        javax.swing.GroupLayout pnlStaffInfoLayout = new javax.swing.GroupLayout(pnlStaffInfo);
        pnlStaffInfo.setLayout(pnlStaffInfoLayout);
        pnlStaffInfoLayout.setHorizontalGroup(
            pnlStaffInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStaffInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlStaffInfoLayout.setVerticalGroup(
            pnlStaffInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStaffInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabReports.addTab("Support Staff Information", pnlStaffInfo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tabReports, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabReports)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ReportManagementGUI().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JPanel pnlCustomerStatistics;
    private javax.swing.JPanel pnlDriverStatistics;
    private javax.swing.JPanel pnlOrderStatistics;
    private javax.swing.JPanel pnlPaymentStatistics;
    private javax.swing.JPanel pnlRestaurantInfo;
    private javax.swing.JPanel pnlStaffInfo;
    private javax.swing.JTabbedPane tabReports;
    private javax.swing.JTextArea txtCustomerStatistics;
    private javax.swing.JTextArea txtDriverStatistics;
    private javax.swing.JTextArea txtOrderStatistics;
    private javax.swing.JTextArea txtPaymentStatistics;
    private javax.swing.JTextArea txtRestaurantInfo;
    private javax.swing.JTextArea txtSupportStaffInfo;
    // End of variables declaration//GEN-END:variables
}
