/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.ArrayList;

/**
 * This class manages all data shared across GUI windows
 * @author Evan Darmanto
 * Date: 12/03/25
 * Assignment: Stage 4 Final Project, CSCI 2210
 */
public class DataManager {
    private static DataManager instance;
    
    private ArrayList<Customer> customers;
    private ArrayList<DeliveryDriver> drivers;
    private ArrayList<Restaurant> restaurants;
    private ArrayList<Order> orders;
    private ArrayList<Payment> payments;
    private ArrayList<SupportStaff> supportStaff;
    private PersonManager personManager;
    
    /**
     * Private constructor for singleton pattern
     */
    private DataManager() {
        customers = new ArrayList<>();
        drivers = new ArrayList<>();
        restaurants = new ArrayList<>();
        orders = new ArrayList<>();
        payments = new ArrayList<>();
        supportStaff = new ArrayList<>();
        personManager = new PersonManager();
        
        // Initialize with dummy data
        initializeDummyData();
    }
    
    /**
     * Get the singleton instance
     * @return The DataManager instance
     */
    public static DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }
    
    /**
     * Initialize dummy data for testing
     */
    private void initializeDummyData() {
        // Create customers
        Customer customer1 = new Customer("John Smith", 28);
        customer1.setEmail("john@email.com");
        customer1.setAddress("123 Main St, Portales, NM");
        customers.add(customer1);
        personManager.addCustomer(customer1);

        Customer customer2 = new Customer("Sarah Johnson", 35);
        customer2.setEmail("sarah@email.com");
        customer2.setAddress("456 Oak Ave, Portales, NM");
        customers.add(customer2);
        personManager.addCustomer(customer2);

        Customer customer3 = new Customer("Michael Chen", 42);
        customer3.setEmail("michael@email.com");
        customer3.setAddress("789 Pine Rd, Portales, NM");
        customers.add(customer3);
        personManager.addCustomer(customer3);

        // Create delivery drivers
        DeliveryDriver driver1 = new DeliveryDriver("Mike Williams", 32, 1001);
        driver1.setEmail("mike@delivery.com");
        driver1.addRating(5);
        driver1.addRating(4);
        driver1.addRating(5);
        drivers.add(driver1);
        personManager.addDriver(driver1);

        DeliveryDriver driver2 = new DeliveryDriver("Lisa Brown", 27, 1002);
        driver2.setEmail("lisa@delivery.com");
        driver2.addRating(5);
        driver2.addRating(5);
        driver2.addRating(4);
        drivers.add(driver2);
        personManager.addDriver(driver2);

        // Create support staff
        SupportStaff staff1 = new SupportStaff("Emma Davis", 29, 2001, 101, "General Support");
        staff1.setEmail("emma@support.com");
        supportStaff.add(staff1);
        personManager.addStaff(staff1);

        // Create restaurants with menus
        Restaurant restaurant1 = new Restaurant(1, "Pizza Palace", "575-555-0100", "11:00 AM");
        MenuItem pizza = new MenuItem(1, "Pepperoni Pizza", "Classic pepperoni with mozzarella", 12.99f);
        pizza.setAllergenInfo("Dairy, Gluten");
        pizza.setCategory("Main Course");
        restaurant1.getMenu().addMenuItem(pizza);

        MenuItem salad = new MenuItem(2, "Caesar Salad", "Fresh romaine with caesar dressing", 8.99f);
        salad.setAllergenInfo("Dairy");
        salad.setCategory("Appetizer");
        restaurant1.getMenu().addMenuItem(salad);
        restaurants.add(restaurant1);

        Restaurant restaurant2 = new Restaurant(2, "Burger Haven", "575-555-0200", "10:00 AM");
        MenuItem burger = new MenuItem(3, "Classic Burger", "Beef patty with lettuce and tomato", 10.99f);
        burger.setAllergenInfo("Gluten");
        burger.setCategory("Main Course");
        restaurant2.getMenu().addMenuItem(burger);

        MenuItem fries = new MenuItem(4, "French Fries", "Crispy golden fries", 4.99f);
        fries.setCategory("Appetizer");
        restaurant2.getMenu().addMenuItem(fries);
        restaurants.add(restaurant2);

        // Create sample orders
        Order order1 = new Order(customer1);
        order1.setTimeAndDate("12:30 PM", "11/03/2025");
        order1.setSpecialInstructions("Ring doorbell twice");
        orders.add(order1);

        Order order2 = new Order(customer2);
        order2.setTimeAndDate("1:15 PM", "11/03/2025");
        order2.updateOrderStatus("In Progress");
        orders.add(order2);
    }
    
    // Getters
    public ArrayList<Customer> getCustomers() { return customers; }
    public ArrayList<DeliveryDriver> getDrivers() { return drivers; }
    public ArrayList<Restaurant> getRestaurants() { return restaurants; }
    public ArrayList<Order> getOrders() { return orders; }
    public ArrayList<Payment> getPayments() { return payments; }
    public ArrayList<SupportStaff> getSupportStaff() { return supportStaff; }
    public PersonManager getPersonManager() { return personManager; }
}